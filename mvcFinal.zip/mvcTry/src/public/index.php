<?php
//Require libraries from folder libraries
require_once '../app/require.php';
