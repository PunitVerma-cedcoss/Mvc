<?php
//require Libraries from folder
require_once 'libraries/Core.php';
require_once 'libraries/Controller.php';
require_once 'libraries/Database.php';
require_once 'config/config.php';
use App\Core;

//init Core
$init = new Core();
