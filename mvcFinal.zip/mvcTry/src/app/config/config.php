<?php
//Database params
define('DB_HOST', 'mysql-server');
define('DB_USER', 'root');
define('DB_PASS', 'secret');
define('DB_NAME', 'test');
// APPROOT
define('APPROOT', dirname(dirname(__FILE__)));
//urlROOT
define('URLROOT', 'localhost');
//sideName
define('SITENAME', 'MVC Framework');
